import Signup from "./pages/Signup";
import Login from "./pages/Login";

export default function App() {
  return (
    <>
      <Signup />
      <Login />
    </>
  );
}
